ANCAP Screensaver - Instalación en Windows
==========================================

Este paquete contiene un screensaver libertario para Windows.

📁 Contenido:
- ANCAP.saver/ - Archivos del screensaver
- ANCAP.scr - Archivo ejecutable del screensaver
- README-Windows.txt - Este archivo

🔧 Instalación Manual:

1. Copia la carpeta "ANCAP.saver" a:
   C:\Windows\System32\ANCAP.saver

2. Copia el archivo "ANCAP.scr" a:
   C:\Windows\System32\ANCAP.scr

3. Configurar el screensaver:
   - Click derecho en el escritorio
   - Seleccionar "Personalizar"
   - Click en "Protector de pantalla"
   - Seleccionar "ANCAP" de la lista
   - Configurar tiempo de espera
   - Click en "Aplicar" y "Aceptar"

🚀 Uso:
- El screensaver se activará automáticamente
- Usa flechas del teclado o barra espaciadora para cambiar citas
- Compatible con Windows 10 y 11

💡 Características:
- 25 citas libertarias auténticas
- Efecto máquina de escribir
- Detección automática de idioma
- Diseño minimalista y profesional
- Completamente gratuito

🌐 Más información:
https://github.com/monarch-one/ancap-screensaver
