# ANCAP Screensaver - Instaladores Multiplataforma

## 🚀 Descarga Todo en Uno

Este ZIP contiene instaladores para **macOS**, **Linux** y **Windows** en un solo archivo.

---

## 🍎 macOS

### Opción 1: Instalador Manual (RECOMENDADO - Sin alertas de seguridad)

```bash
# 1. Extrae este ZIP
# 2. Abre Terminal
# 3. Navega a la carpeta extraída
cd "ruta/a/ANCAP-Screensaver-Universal-v1.1.2"

# 4. Ejecuta el instalador manual
chmod +x macos-installers/install-manual.sh
sudo ./macos-installers/install-manual.sh
```

**Ventajas:**
- ✅ Sin alertas de seguridad
- ✅ Instalación directa
- ✅ Control total del proceso

### Opción 2: Instalador .pkg (Con alerta de seguridad)

```bash
# 1. Doble clic en ANCAP-Screensaver-macOS-v1.1.1.pkg
# 2. Aparecerá alerta de seguridad
# 3. Ve a Sistema → Seguridad y Privacidad
# 4. Haz clic en "Abrir de todas formas"
```

**Después de la instalación:**
1. Preferencias del Sistema → Escritorio y Protector de pantalla
2. Pestaña "Protector de pantalla"
3. Seleccionar "ANCAP" de la lista
4. Configurar tiempo de inactividad
5. Hacer clic en "Aceptar"

---

## 🐧 Linux

### Instalación:

```bash
# 1. Extrae este ZIP
# 2. Abre Terminal
# 3. Navega a la carpeta extraída
cd "ruta/a/ANCAP-Screensaver-Universal-v1.1.2"

# 4. Instala manualmente
sudo cp -R ANCAP.saver /usr/share/ancap-screensaver/
sudo chmod -R 755 /usr/share/ancap-screensaver/

# 5. Crear entrada de escritorio (opcional)
sudo cp linux-installers/ancap-screensaver.desktop /usr/share/applications/
```

**Activación:**
- Busca "ANCAP Screensaver" en el menú de aplicaciones
- O ejecuta: `firefox --kiosk file:///usr/share/ancap-screensaver/index.html`

---

## 🪟 Windows

### Instalación:

```cmd
# 1. Extrae este ZIP
# 2. Abre CMD como Administrador
# 3. Navega a la carpeta extraída
cd "ruta\a\ANCAP-Screensaver-Universal-v1.1.2"

# 4. Copia archivos al sistema
copy ANCAP.saver C:\Windows\System32\
copy ANCAP.scr C:\Windows\System32\
```

**Activación:**
1. Click derecho en escritorio → Personalizar
2. Protector de pantalla
3. Seleccionar "ANCAP" de la lista
4. Configurar tiempo de espera
5. Aplicar y Aceptar

---

## 📁 Contenido del ZIP

```
ANCAP-Screensaver-Universal-v1.1.2/
├── README-Universal.md (este archivo)
├── ANCAP.saver/ (archivos del screensaver)
├── macos-installers/
│   ├── install-manual.sh (instalador sin alertas)
│   ├── ANCAP-Screensaver-macOS-v1.1.1.pkg
│   └── README-macOS.md
├── linux-installers/
│   └── ANCAP-Screensaver-Linux-v1.1.1.zip
└── windows-installers/
    └── ANCAP-Screensaver-Windows-v1.1.1.zip
```

---

## 🎯 Características del Screensaver

- **25 citas libertarias** auténticas
- **Efecto máquina de escribir** envolvente
- **Detección automática** de idioma
- **Tipografía JetBrains Mono** profesional
- **Diseño minimalista** negro y amarillo
- **Completamente gratuito** y de código abierto

---

## 🆘 Soporte

- **GitHub**: [monarch-one/ancap-screensaver](https://github.com/monarch-one/ancap-screensaver)
- **Issues**: [Reportar problemas](https://github.com/monarch-one/ancap-screensaver/issues)
- **Discusiones**: [GitHub Discussions](https://github.com/monarch-one/ancap-screensaver/discussions)

---

## 📄 Licencia

MIT License - Código abierto para la comunidad libertaria.

---

**"La libertad económica es la base de todas las demás libertades."** - Javier Milei

*Desarrollado con ❤️ para la comunidad libertaria*
